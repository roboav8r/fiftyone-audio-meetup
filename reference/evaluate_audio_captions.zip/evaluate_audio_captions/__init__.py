"""
Evaluate audio captions.

| Copyright 2017-2025, Voxel51, Inc.
| `voxel51.com <https://voxel51.com/>`_
|
"""
import fiftyone as fo
import fiftyone.operators as foo
import fiftyone.operators.types as types
import fiftyone.core.utils as fou

from tqdm import tqdm


class EvaluateAudioCaptions(foo.Operator):
    @property
    def config(self):
        return foo.OperatorConfig(
            name="evaluate_audio_captions",
            label="Evaluate audio captions",
            light_icon="/assets/icon-light.svg",
            dark_icon="/assets/icon-dark.svg",
            dynamic=True,
        )

    def __call__(self, sample_collection, pred_field="predictions", gt_field="ground_truth"):
        """Evaluates a prediction vs ground truth fo.Classification field
        storing captions

        Args:
            sample_collection: the fo.Dataset or fo.DatasetView to evaluate
            pred_field ("predictions"): the name of the field containing
                model predictions
            gt_field ("ground_truth"): the name of the field containing
                ground truth captions
        """
        ctx = dict(view=sample_collection.view())
        if pred_field not in sample_collection.get_field_schema():
            raise ValueError("Invalid prediction field '%s', not an existing classification field" % pred_field)
        if gt_field not in sample_collection.get_field_schema():
            raise ValueError("Invalid ground_truth field '%s', not an existing classification field" % gt_field)

        params = dict(
            pred_field=pred_field,
            gt_field=gt_field,
        )
        foo.execute_operator(self.uri, ctx, params=params)
        sample_collection.reload()


    def resolve_input(self, ctx):
        inputs = types.Object()

        fields = types.Dropdown()
        for field in ctx.dataset.get_field_schema():
            fields.add_choice(field, label=field)

        inputs.enum(
            "pred_field",
            fields.values(),
            required=True,
            label="Predictions field",
            description=(
                "The name of the classification field containing predictions"
            ),
            view=fields,
        )
        inputs.enum(
            "gt_field",
            fields.values(),
            required=True,
            label="Ground truth field",
            description=(
                "The name of the classification field containing ground truth captions"
            ),
            view=fields,
        )


        return types.Property(inputs, view=types.View(label="Evaluate audio captions"))

    def execute(self, ctx):
        from aac_metrics import Evaluate
        view = ctx.view
        pred_field = ctx.params.get("pred_field", None)
        gt_field = ctx.params.get("gt_field", None)

        dataset = ctx.dataset
        evaluate = Evaluate(metrics=["spider", "fense", "vocab", "spider_fl"])

        view = dataset.exists("predictions").exists("ground_truth")
        candidates = view.values("predictions.label")
        mult_references = [[l] for l in view.values("ground_truth.label")]

        print("Evaluating...")
        corpus_scores, results = evaluate(candidates, mult_references)

        print("Setting results...")
        view.set_values("spider", results["spider"].tolist())
        view.set_values("spider_fl", results["spider_fl"].tolist())
        view.set_values("vocab", results["vocab.cands"].tolist())
        view.set_values("fense", results["fense"].tolist())
        view.set_values("sbert_sim", results["sbert_sim"].tolist())
        view.set_values("cider_d", results["cider_d"].tolist())
        view.set_values("spice", results["spice"].tolist())
        view.set_values("predictions.spider", results["spider"].tolist())
        view.set_values("predictions.spider_fl", results["spider_fl"].tolist())
        view.set_values("predictions.vocab", results["vocab.cands"].tolist())
        view.set_values("predictions.fense", results["fense"].tolist())
        view.set_values("predictions.sbert_sim", results["sbert_sim"].tolist())
        view.set_values("predictions.cider_d", results["cider_d"].tolist())
        view.set_values("predictions.spice", results["spice"].tolist())


def register(p):
    p.register(EvaluateAudioCaptions)
