"""
Apply audio captioning models to a FiftyOne Dataset.

| Copyright 2017-2025, Voxel51, Inc.
| `voxel51.com <https://voxel51.com/>`_
|
"""
import fiftyone as fo
import fiftyone.operators as foo
import fiftyone.operators.types as types
import fiftyone.core.utils as fou

from tqdm import tqdm


class ApplyAudioCaptioningModel(foo.Operator):
    @property
    def config(self):
        return foo.OperatorConfig(
            name="apply_audio_captioning_model",
            label="Apply audio captioning model",
            light_icon="/assets/icon-light.svg",
            dark_icon="/assets/icon-dark.svg",
            dynamic=True,
        )

    def __call__(self, sample_collection, label_field="predictions", model="CoNeTTE", media_field="filepath", batch_size=10):
        """Applies an audio captioning model onto a FiftyOne dataset and stores
        the results on fields of the dataset.

        Args:
            sample_collection: the fo.Dataset or fo.DatasetView on which to
                apply the model
            label_field ("predictions"): the name of the field to store the
                model predictions
            model ("CoNeTTE"): the model to apply, options are ["CoNeTTE"]
            media_field ("filepath"): the field containing .wav files to run
                inference on
            batch_size (10): the integer batch size for model inference
        """
        ctx = dict(view=sample_collection.view())
        if label_field and label_field in sample_collection.get_field_schema():
            raise ValueError("Label field '%s' already exists. Provide new field name with the `label_field` kwarg." % label_field)

        if model not in MODELS:
            raise ValueError("Model '%s' does not exist. Options are [%s]" % (model, ", ".join(MODELS.keys())))

        if media_field not in sample_collection.get_field_schema(ftype=fo.StringField):
            raise ValueError("Invalid media field '%s', not an existing string field" % media_field)

        params = dict(
            label_field=label_field,
            model=model,
            media_field=media_field,
            batch_size=batch_size,
        )
        foo.execute_operator(self.uri, ctx, params=params)
        sample_collection.reload()


    def resolve_input(self, ctx):
        inputs = types.Object()

        label_field = inputs.str(
            "label_field",
            required=True,
            label="Label field",
            default="predictions",
            description=(
                "The name of a new field in which to store the "
                "model predictions"
            ),
        )

        if label_field and label_field in ctx.dataset.get_field_schema():
            inputs.str("error", label="Error", view=types.Error())
            py.invalid = True
            py.error_message = "Field already exists"


        models = types.Dropdown()
        for model in MODELS.keys():
            models.add_choice(model, label=model)

        inputs.enum(
            "model",
            models.values(),
            default=models.choices[0].value,
            label="Select model",
            view=models,
        )


        media_fields = types.Dropdown()
        default_field = "filepath"
        for field in ctx.dataset.get_field_schema(ftype=fo.StringField):
            media_fields.add_choice(field, label=field)
            if "wav" in field:
                default_field = field

        inputs.enum(
            "media_field",
            media_fields.values(),
            default=default_field,
            label="Select media field",
            view=media_fields,
        )

        inputs.int(
            "batch_size",
            default=10,
            min=1,
            label="Batch size",
        )

        return types.Property(inputs, view=types.View(label="Apply audio captioning model"))

    def execute(self, ctx):
        view = ctx.view
        label_field = ctx.params.get("label_field", None)
        model = ctx.params.get("model", None)
        media_field = ctx.params.get("media_field", None)
        batch_size = ctx.params.get("batch_size", None)

        apply_model_fcn = MODELS[model]

        apply_model_fcn(
            view,
            label_field,
            batch_size=batch_size,
            media_field=media_field,
        )


def get_paths(samples, media_field="filepath"):
    return samples.values(media_field)


def apply_conette(samples, label_field, batch_size=10, media_field="filepath"):
    from conette import CoNeTTEConfig, CoNeTTEModel

    print("Loading model...")
    config = CoNeTTEConfig.from_pretrained("Labbeti/conette")
    model = CoNeTTEModel.from_pretrained("Labbeti/conette", config=config)


    def apply_batch(batch_paths):
        outputs = model(batch_paths)
        batch_pred_values = {}
        batch_preds_values = {}
        batch_tags_values = {}
        for i, path in enumerate(batch_paths):
            pred = fo.Classification(label=outputs["cands"][i], confidence=float(outputs["lprobs"][i]))
            preds = fo.Classifications(classifications=[
                fo.Classification(label=c, confidence=float(p)) for c,p in zip(outputs["mult_cands"][i], outputs["mult_lprobs"][i])
            ])
            tags = outputs["tags"][i]

            batch_pred_values[path] = pred
            batch_preds_values[path] = preds
            batch_tags_values[path] = tags

        return batch_pred_values, batch_preds_values, batch_tags_values

    pred_values = {}
    preds_values = {}
    tags_values = {}
    paths = get_paths(samples, media_field=media_field)
    print("Running inference...")
    for paths in tqdm(fou.iter_batches(paths, batch_size=batch_size), total=len(paths)/batch_size):
        try:
            pred, preds, tags = apply_batch(paths)
            pred_values.update(pred)
            preds_values.update(preds)
            tags_values.update(tags)

        except Exception as e:
            print(e)

    samples.set_values(label_field, pred, key_field=media_field)
    samples.set_values("multi_"+label_field, preds, key_field=media_field)
    samples.set_values("tags_"+label_field, tags, key_field=media_field)


MODELS = {
    "CoNeTTE": apply_conette
}

def register(p):
    p.register(ApplyAudioCaptioningModel)
