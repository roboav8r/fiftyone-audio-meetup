"""
FiftyOne Dataset Table View Plugin

Backend operators for fetching dataset schema and samples in tabular format.
"""
import fiftyone as fo
import fiftyone.operators as foo
import fiftyone.operators.types as types
import fiftyone.core.storage as fos
import fiftyone.brain as fob
from fiftyone.core.fields import EmbeddedDocumentField, ListField


def get_nested_fields(field, parent_path="", max_depth=3, current_depth=0):
    """Recursively get nested fields from embedded documents.

    Args:
        field: The field to traverse
        parent_path: The parent path (e.g., "predictions")
        max_depth: Maximum depth to traverse (prevent infinite recursion)
        current_depth: Current recursion depth

    Returns:
        List of (path, type_name) tuples
    """
    fields = []
    field_type = field.__class__.__name__

    # If this is an embedded document field, traverse its subfields
    if isinstance(field, EmbeddedDocumentField) and current_depth < max_depth:
        try:
            # Get the document type
            document_cls = field.document_type
            if document_cls and hasattr(document_cls, '_fields'):
                for subfield_name, subfield in document_cls._fields.items():
                    # Skip private fields
                    if subfield_name.startswith('_'):
                        continue

                    subfield_path = f"{parent_path}.{subfield_name}" if parent_path else subfield_name
                    subfield_type = subfield.__class__.__name__

                    # Add the subfield
                    fields.append((subfield_path, subfield_type))

                    # Recursively traverse nested embedded documents
                    if isinstance(subfield, EmbeddedDocumentField):
                        nested = get_nested_fields(subfield, subfield_path, max_depth, current_depth + 1)
                        fields.extend(nested)

                    # Handle ListField that contains embedded documents (e.g., Detections)
                    elif isinstance(subfield, ListField) and hasattr(subfield, 'field'):
                        list_element_field = subfield.field
                        if isinstance(list_element_field, EmbeddedDocumentField):
                            # Get the document type for the list elements
                            element_doc_cls = list_element_field.document_type
                            if element_doc_cls and hasattr(element_doc_cls, '_fields'):
                                for elem_field_name, elem_field in element_doc_cls._fields.items():
                                    if elem_field_name.startswith('_'):
                                        continue
                                    elem_field_path = f"{subfield_path}.{elem_field_name}"
                                    elem_field_type = elem_field.__class__.__name__
                                    fields.append((elem_field_path, elem_field_type))

                                    # Recursively traverse if the element field is also embedded
                                    if isinstance(elem_field, EmbeddedDocumentField):
                                        nested = get_nested_fields(elem_field, elem_field_path, max_depth, current_depth + 2)
                                        fields.extend(nested)
        except Exception:
            # If we can't traverse, just return empty
            pass

    return fields


def get_nested_value(obj, path):
    """Get a nested value from an object using dot notation.

    Args:
        obj: The object (e.g., a sample)
        path: The path (e.g., "predictions.label")

    Returns:
        The value at that path, or None if not found
    """
    parts = path.split('.')
    current = obj

    for part in parts:
        if current is None:
            return None

        # Handle dictionary access
        if isinstance(current, dict):
            current = current.get(part)
        # Handle list of objects (like Detections)
        elif isinstance(current, list):
            # Extract the attribute from each item in the list
            try:
                values = []
                for item in current:
                    if hasattr(item, part):
                        val = getattr(item, part)
                        if val is not None:
                            values.append(val)
                    elif isinstance(item, dict) and part in item:
                        val = item[part]
                        if val is not None:
                            values.append(val)
                return values if values else None
            except Exception:
                return None
        # Handle object attribute access
        elif hasattr(current, part):
            current = getattr(current, part)
        else:
            return None

    return current


def format_value(value, max_length=200):
    """Format a value for display in a table cell.

    Args:
        value: The value to format
        max_length: Maximum string length

    Returns:
        A string representation of the value
    """
    if value is None:
        return None

    # Handle primitive types
    if isinstance(value, (str, int, float, bool)):
        result = str(value)
        return result[:max_length] if len(result) > max_length else result

    # Handle lists
    if isinstance(value, list):
        if not value:
            return "[]"

        # Check if all items are primitives
        if all(isinstance(v, (str, int, float, bool)) for v in value):
            # Format as comma-separated list
            result = ", ".join(str(v) for v in value)
            if len(result) > max_length:
                # Show first few items and count
                truncated = ", ".join(str(v) for v in value[:3])
                return f"{truncated}, ... ({len(value)} total)"
            return result
        else:
            # Complex objects, just show count
            return f"[{len(value)} items]"

    # For other objects, use string representation
    result = str(value)
    return result[:max_length] if len(result) > max_length else result


class GetDatasetSchema(foo.Operator):
    """Get the schema (fields) of the current dataset, including nested fields."""

    @property
    def config(self):
        return foo.OperatorConfig(
            name="get_dataset_schema",
            label="Get Dataset Schema",
            unlisted=True,
        )

    def resolve_input(self, ctx):
        inputs = types.Object()
        return types.Property(inputs)

    def execute(self, ctx):
        dataset = ctx.dataset
        if not dataset:
            return {"fields": [], "media_type": None}

        # Get dataset media type
        media_type = dataset.media_type

        # Get all field names and types
        schema = dataset.get_field_schema()
        fields = []

        for field_name, field in schema.items():
            # Get field type as string
            field_type = field.__class__.__name__

            # Add the top-level field
            fields.append({
                "name": field_name,
                "type": field_type,
                "path": field_name,
            })

            # If this is an embedded document, add its nested fields
            if isinstance(field, EmbeddedDocumentField):
                nested = get_nested_fields(field, field_name)
                for nested_path, nested_type in nested:
                    fields.append({
                        "name": nested_path,
                        "type": nested_type,
                        "path": nested_path,
                    })

        # Sort fields alphabetically
        fields.sort(key=lambda x: x["name"])

        return {"fields": fields, "media_type": media_type}


class GetSamples(foo.Operator):
    """Get paginated samples from the current dataset."""

    @property
    def config(self):
        return foo.OperatorConfig(
            name="get_samples",
            label="Get Samples",
            unlisted=True,
        )

    def resolve_input(self, ctx):
        inputs = types.Object()
        inputs.list(
            "fields",
            types.String(),
            label="Fields to retrieve",
            description="List of field names to include",
        )
        inputs.list(
            "audio_fields",
            types.String(),
            label="Audio/video fields",
            description="Fields that should have URLs resolved for audio/video playback",
            default=[],
        )
        inputs.int(
            "skip",
            label="Skip",
            description="Number of samples to skip",
            default=0,
        )
        inputs.int(
            "limit",
            label="Limit",
            description="Number of samples to return",
            default=10,
        )
        return types.Property(inputs)

    def execute(self, ctx):
        dataset = ctx.dataset
        if not dataset:
            return {"samples": [], "total": 0}

        # Get parameters
        fields = ctx.params.get("fields", [])
        audio_fields = ctx.params.get("audio_fields", [])
        skip = ctx.params.get("skip", 0)
        limit = ctx.params.get("limit", 10)

        # Get the current view (respects filters)
        view = ctx.view or dataset

        # Total count
        total = len(view)

        # Fetch samples with pagination
        samples_view = view.skip(skip).limit(limit)

        # Build response
        samples = []
        audio_urls = {}  # Map of sample_id -> {field_path -> resolved_url}

        for sample in samples_view:
            sample_data = {"id": sample.id}
            sample_audio_urls = {}

            for field_path in fields:
                try:
                    # Get nested value using dot notation
                    value = get_nested_value(sample, field_path)

                    # Format the value for display
                    sample_data[field_path] = format_value(value)

                    # If this is an audio field, resolve URL for playback
                    if field_path in audio_fields and value is not None:
                        try:
                            # Resolve URL for cloud storage
                            resolved_url = fos.get_url(value)
                            sample_audio_urls[field_path] = resolved_url
                        except Exception:
                            # If URL resolution fails, use original value
                            sample_audio_urls[field_path] = value

                except Exception as e:
                    # If field access fails, set to error message
                    sample_data[field_path] = f"Error: {str(e)}"

            samples.append(sample_data)
            if sample_audio_urls:
                audio_urls[sample.id] = sample_audio_urls

        return {
            "samples": samples,
            "audio_urls": audio_urls,
            "total": total,
            "skip": skip,
            "limit": limit,
        }


class GetDefaultColumns(foo.Operator):
    """Get the saved default columns for this dataset."""

    @property
    def config(self):
        return foo.OperatorConfig(
            name="get_default_columns",
            label="Get Default Columns",
            unlisted=True,
        )

    def resolve_input(self, ctx):
        inputs = types.Object()
        return types.Property(inputs)

    def execute(self, ctx):
        dataset = ctx.dataset
        if not dataset:
            return {"columns": None}

        # Get plugin settings from dataset app config
        plugin_config = dataset.app_config.plugins.get("@voxel51/dataset-table-view", {})
        default_columns = plugin_config.get("default_columns", None)

        return {"columns": default_columns}


class SetDefaultColumns(foo.Operator):
    """Save default columns for this dataset."""

    @property
    def config(self):
        return foo.OperatorConfig(
            name="set_default_columns",
            label="Set Default Columns",
            unlisted=True,
        )

    def resolve_input(self, ctx):
        inputs = types.Object()
        inputs.list(
            "columns",
            types.String(),
            label="Default columns",
            description="List of field names to use as defaults",
        )
        return types.Property(inputs)

    def execute(self, ctx):
        dataset = ctx.dataset
        if not dataset:
            return {"success": False, "error": "No dataset"}

        columns = ctx.params.get("columns", [])

        # Get or create plugin config
        if "@voxel51/dataset-table-view" not in dataset.app_config.plugins:
            dataset.app_config.plugins["@voxel51/dataset-table-view"] = {}

        # Save default columns
        dataset.app_config.plugins["@voxel51/dataset-table-view"]["default_columns"] = columns

        # Save the dataset to persist changes
        dataset.save()

        return {"success": True, "columns": columns}


class TagSamplesInTable(foo.Operator):
    """Add or remove tags from selected samples in the table view."""

    @property
    def config(self):
        return foo.OperatorConfig(
            name="tag_samples_in_table",
            label="Tag samples",
            description="Add or remove tags from selected samples",
            unlisted=True,  # Don't show in placements, only callable directly
            dynamic=True,
        )

    def resolve_input(self, ctx):
        inputs = types.Object()

        # Get current tags from dataset
        dataset = ctx.dataset
        all_tags = set()
        if dataset:
            for sample in dataset.select_fields("tags"):
                if sample.tags:
                    all_tags.update(sample.tags)

        inputs.str(
            "tag",
            label="Tag name",
            description="Enter a tag name",
            required=True,
        )

        inputs.enum(
            "action",
            ["add", "remove"],
            default="add",
            label="Action",
            description="Add or remove the tag",
            view=types.RadioGroup(),
        )

        # Show existing tags as suggestions
        if all_tags:
            inputs.str(
                "existing_tags_hint",
                label="Existing tags",
                description=", ".join(sorted(all_tags)),
                view=types.View(read_only=True),
            )

        return types.Property(inputs)

    def execute(self, ctx):
        tag = ctx.params.get("tag")
        action = ctx.params.get("action", "add")

        # Get selected samples
        selected_samples = ctx.selected
        if not selected_samples:
            ctx.ops.notify("No samples selected", variant="warning")
            return

        # Get the view with selected samples
        view = ctx.view.select(selected_samples)

        # Add or remove tag
        if action == "add":
            view.tag_samples(tag)
            ctx.ops.notify(f"Added tag '{tag}' to {len(selected_samples)} sample(s)", variant="success")
        else:
            view.untag_samples(tag)
            ctx.ops.notify(f"Removed tag '{tag}' from {len(selected_samples)} sample(s)", variant="success")

        # Trigger refresh
        ctx.ops.reload_dataset()


class SimilaritySearchInTable(foo.Operator):
    """Search for similar samples using embeddings."""

    @property
    def config(self):
        return foo.OperatorConfig(
            name="similarity_search_in_table",
            label="Similarity search",
            description="Find similar samples using embedding similarity",
            unlisted=True,  # Don't show in placements, only callable directly
            dynamic=True,
        )

    def resolve_input(self, ctx):
        inputs = types.Object()

        dataset = ctx.dataset
        if not dataset:
            return types.Property(inputs)

        # Get available brain keys for similarity
        brain_keys = dataset.list_brain_runs()
        similarity_keys = [
            key for key in brain_keys
            if dataset.get_brain_info(key).config.get("method") == "similarity"
        ]

        if not similarity_keys:
            inputs.str(
                "no_similarity_hint",
                label="No similarity indexes found",
                description="Run fiftyone.brain.compute_similarity() first to create an index",
                view=types.View(read_only=True),
            )
            return types.Property(inputs)

        inputs.enum(
            "brain_key",
            similarity_keys,
            default=similarity_keys[0] if similarity_keys else None,
            label="Similarity index",
            description="Choose which similarity index to use",
            required=True,
        )

        inputs.int(
            "k",
            default=50,
            label="Number of results",
            description="How many similar samples to find",
            view=types.SliderView(min=1, max=1000),
        )

        # Option to reverse (most different instead of most similar)
        inputs.bool(
            "reverse",
            default=False,
            label="Reverse (find most different)",
            description="Find the most different samples instead of most similar",
        )

        return types.Property(inputs)

    def execute(self, ctx):
        brain_key = ctx.params.get("brain_key")
        k = ctx.params.get("k", 50)
        reverse = ctx.params.get("reverse", False)

        # Get selected samples (should be exactly one for similarity search from)
        selected_samples = ctx.selected
        if not selected_samples:
            ctx.ops.notify("Please select one sample to find similar samples", variant="warning")
            return

        if len(selected_samples) > 1:
            ctx.ops.notify("Please select only one sample for similarity search", variant="warning")
            return

        # Get the sample ID
        sample_id = list(selected_samples)[0]

        # Get the dataset
        dataset = ctx.dataset
        view = ctx.view

        try:
            # Use sort_by_similarity view method to find similar samples
            similar_view = view.sort_by_similarity(
                sample_id,
                k=k,
                reverse=reverse,
                brain_key=brain_key,
            )

            # Set this as the current view
            ctx.ops.set_view(view=similar_view)

            action_word = "different" if reverse else "similar"
            ctx.ops.notify(
                f"Found {k} most {action_word} samples",
                variant="success"
            )

        except Exception as e:
            ctx.ops.notify(f"Error: {str(e)}", variant="error")


def register(plugin):
    """Register operators."""
    plugin.register(GetDatasetSchema)
    plugin.register(GetSamples)
    plugin.register(GetDefaultColumns)
    plugin.register(SetDefaultColumns)
    plugin.register(TagSamplesInTable)
    plugin.register(SimilaritySearchInTable)
