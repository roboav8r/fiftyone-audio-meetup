import { Button } from "@fiftyone/components";
import { useOperatorExecutor } from "@fiftyone/operators";
import * as fos from "@fiftyone/state";
import {
  useSetExpandedSample,
  useSetModalState,
} from "@fiftyone/state";
import {
  Box,
  FormControl,
  MenuItem,
  Select,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  CircularProgress,
  Alert,
  SelectChangeEvent,
  Chip,
  Tooltip,
  TextField,
  IconButton,
  Checkbox,
} from "@mui/material";
import GraphicEqIcon from "@mui/icons-material/GraphicEq";
import { useEffect, useState } from "react";
import { useRecoilValue, useSetRecoilState } from "recoil";
import styled from "styled-components";
import TableActions from "./TableActions";

// Minimal container - let content breathe
const Container = styled.div`
  height: 100%;
  display: flex;
  flex-direction: column;
  background: var(--fo-palette-background-body, #161616);
`;

// Clean header with proper spacing
const Header = styled.div`
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 16px;
  border-bottom: 1px solid var(--fo-palette-divider, rgba(255, 255, 255, 0.12));
`;

const Title = styled.h3`
  margin: 0;
  font-size: 14px;
  font-weight: 600;
  color: var(--fo-palette-text-primary, rgba(255, 255, 255, 0.9));
  letter-spacing: 0.01em;
`;

// Table wrapper that fills remaining space
const TableWrapper = styled.div`
  flex: 1;
  overflow: auto;
  min-height: 0;
  position: relative;

  /* Scrollbar styling that respects theme */
  &::-webkit-scrollbar {
    width: 12px;
    height: 12px;
  }

  &::-webkit-scrollbar-track {
    background: var(--fo-palette-background-body, #161616);
  }

  &::-webkit-scrollbar-thumb {
    background: var(--fo-palette-divider, rgba(255, 255, 255, 0.12));
    border-radius: 6px;
    border: 2px solid var(--fo-palette-background-body, #161616);
  }

  &::-webkit-scrollbar-thumb:hover {
    background: var(--fo-palette-text-tertiary, rgba(255, 255, 255, 0.4));
  }

  /* Firefox scrollbar */
  scrollbar-width: thin;
  scrollbar-color: var(--fo-palette-divider, rgba(255, 255, 255, 0.12))
    var(--fo-palette-background-body, #161616);
`;

// Pagination at bottom
const PaginationWrapper = styled.div`
  border-top: 1px solid var(--fo-palette-divider, rgba(255, 255, 255, 0.12));
`;

interface Field {
  name: string;
  type: string;
  path: string;
}

interface Sample {
  id: string;
  [key: string]: any;
}

interface SamplesResult {
  samples: Sample[];
  total: number;
  skip: number;
  limit: number;
}

/**
 * Get smart default fields based on available fields
 */
function getSmartDefaultFields(fields: Field[]): string[] {
  const fieldNames = fields.map((f) => f.name);
  const fieldsMap = new Map(fields.map((f) => [f.name, f]));
  const selected: string[] = [];

  // 1. Always start with filepath if available
  if (fieldNames.includes("filepath")) {
    selected.push("filepath");
  }

  // 2. Add created_at if available
  if (fieldNames.includes("created_at")) {
    selected.push("created_at");
  }

  // 3. Find label fields (Classification, Detection, Segmentation, etc.)
  // Look for fields that are embedded documents and have a .label subfield
  const labelFieldTypes = [
    "EmbeddedDocumentField",
    "ClassificationField",
    "DetectionField",
    "DetectionsField",
    "PolylineField",
    "PolylinesField",
    "KeypointField",
    "KeypointsField",
    "SegmentationField",
  ];

  // Find top-level label fields
  const topLevelLabelFields = fields.filter((f) =>
    labelFieldTypes.some((type) => f.type.includes(type))
  );

  // For each label field, prefer the .label subfield if it exists
  for (const labelField of topLevelLabelFields) {
    const labelSubfield = `${labelField.name}.label`;
    const detectionsLabelSubfield = `${labelField.name}.detections.label`;

    // Check if it's a Detections field (list of detections)
    if (
      labelField.type.includes("Detections") &&
      fieldNames.includes(detectionsLabelSubfield)
    ) {
      if (!selected.includes(detectionsLabelSubfield)) {
        selected.push(detectionsLabelSubfield);
        if (selected.length >= 5) break;
      }
    }
    // Otherwise check for direct .label subfield
    else if (fieldNames.includes(labelSubfield)) {
      if (!selected.includes(labelSubfield)) {
        selected.push(labelSubfield);
        if (selected.length >= 5) break;
      }
    }
    // Fallback to the top-level field
    else if (!selected.includes(labelField.name)) {
      selected.push(labelField.name);
      if (selected.length >= 5) break;
    }
  }

  // 4. Add other useful fields
  const otherUsefulFields = [
    "id",
    "tags",
    "metadata.width",
    "metadata.height",
  ];

  for (const fieldName of otherUsefulFields) {
    if (
      fieldNames.includes(fieldName) &&
      !selected.includes(fieldName) &&
      selected.length < 5
    ) {
      selected.push(fieldName);
    }
  }

  // 5. Fill remaining slots with any .label or .confidence fields
  if (selected.length < 5) {
    const labelConfidenceFields = fieldNames.filter(
      (name) =>
        (name.endsWith(".label") || name.endsWith(".confidence")) &&
        !selected.includes(name)
    );
    for (const field of labelConfidenceFields) {
      if (!selected.includes(field)) {
        selected.push(field);
        if (selected.length >= 5) break;
      }
    }
  }

  // 6. If still not enough, add leaf fields (nested fields, not top-level embedded docs)
  if (selected.length < 5) {
    const leafFields = fields.filter(
      (f) =>
        !selected.includes(f.name) &&
        (f.name.includes(".") ||
          ["StringField", "IntField", "FloatField", "BooleanField"].includes(
            f.type
          ))
    );

    for (const field of leafFields) {
      if (!selected.includes(field.name)) {
        selected.push(field.name);
        if (selected.length >= 5) break;
      }
    }
  }

  // 7. If still not enough, just add any remaining fields
  if (selected.length < 5) {
    for (const name of fieldNames) {
      if (!selected.includes(name)) {
        selected.push(name);
        if (selected.length >= 5) break;
      }
    }
  }

  return selected;
}

export function DatasetTableView() {
  const dataset = useRecoilValue(fos.dataset);
  const view = useRecoilValue(fos.view);
  const filters = useRecoilValue(fos.filters);
  const extendedSelection = useRecoilValue(fos.extendedSelection);
  const selectedSamples = useRecoilValue(fos.selectedSamples);
  const setSelectedSamples = useSetRecoilState(fos.selectedSamples);
  const theme = useRecoilValue(fos.theme);
  const [fields, setFields] = useState<Field[]>([]);
  const [selectedColumns, setSelectedColumns] = useState<string[]>([]); // Can include "field" and "field__AUDIO__"
  const [mediaType, setMediaType] = useState<string | null>(null);
  const [samples, setSamples] = useState<Sample[]>([]);
  const [audioUrls, setAudioUrls] = useState<Record<string, Record<string, string>>>({});
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(25);
  const [savedColumns, setSavedColumns] = useState<string[] | null>(null);
  const [pageJumpInput, setPageJumpInput] = useState("");
  const [columnWidths, setColumnWidths] = useState<Record<string, number>>({});
  const [resizingColumn, setResizingColumn] = useState<string | null>(null);
  const [draggedColumn, setDraggedColumn] = useState<string | null>(null);
  const [dragOverColumn, setDragOverColumn] = useState<string | null>(null);

  // Modal state for opening samples
  const setModalState = useSetModalState();
  const setExpandedSample = useSetExpandedSample();

  // Operators
  const schemaExecutor = useOperatorExecutor(
    "@voxel51/dataset-table-view/get_dataset_schema"
  );
  const samplesExecutor = useOperatorExecutor(
    "@voxel51/dataset-table-view/get_samples"
  );
  const getDefaultsExecutor = useOperatorExecutor(
    "@voxel51/dataset-table-view/get_default_columns"
  );
  const setDefaultsExecutor = useOperatorExecutor(
    "@voxel51/dataset-table-view/set_default_columns"
  );

  // Load schema and saved defaults on mount or dataset change
  useEffect(() => {
    if (dataset) {
      schemaExecutor.execute({});
      getDefaultsExecutor.execute({});
      setPage(0);
    }
  }, [dataset]);

  // Update savedColumns when defaults are loaded
  useEffect(() => {
    if (getDefaultsExecutor.result) {
      const columns = getDefaultsExecutor.result.columns;
      setSavedColumns(columns || null);
    }
  }, [getDefaultsExecutor.result]);

  // Reset to first page when view/filters/selection change
  useEffect(() => {
    setPage(0);
  }, [view, filters, extendedSelection]);

  // When schema loads, set fields and default selection
  useEffect(() => {
    if (schemaExecutor.result?.fields) {
      const fieldsList = schemaExecutor.result.fields as Field[];
      setFields(fieldsList);

      // Store media type
      const mediaTypeValue = schemaExecutor.result.media_type as string | null;
      setMediaType(mediaTypeValue);

      let defaultColumns: string[];
      let defaultWidths: Record<string, number> = {};

      if (savedColumns && savedColumns.length > 0) {
        // Parse saved columns to extract column IDs and widths
        const availableFieldNames = new Set(fieldsList.map((f) => f.name));
        defaultColumns = [];

        for (const col of savedColumns) {
          // Parse format: "fieldname::width" or "fieldname__AUDIO__::width"
          const parts = col.split("::");
          const columnId = parts[0]; // Could be "field" or "field__AUDIO__"
          const width = parts[1] ? parseInt(parts[1], 10) : undefined;

          // Extract base field name
          const baseFieldName = columnId.endsWith("__AUDIO__")
            ? columnId.replace("__AUDIO__", "")
            : columnId;

          if (availableFieldNames.has(baseFieldName)) {
            defaultColumns.push(columnId);
            if (width && !isNaN(width)) {
              defaultWidths[columnId] = width;
            }
          }
        }

        // If all saved fields are gone, fall back to smart defaults
        if (defaultColumns.length === 0) {
          defaultColumns = getSmartDefaultFields(fieldsList);
          defaultWidths = {};
        }
      } else {
        // No saved defaults, use smart defaults
        defaultColumns = getSmartDefaultFields(fieldsList);
      }

      setSelectedColumns(defaultColumns);
      setColumnWidths(defaultWidths);
    }
  }, [schemaExecutor.result, savedColumns]);

  // Load samples when columns, page, rowsPerPage, view, filters, or selection change
  useEffect(() => {
    if (selectedColumns.length > 0) {
      const skip = page * rowsPerPage;

      // Extract unique field names and audio field names
      const uniqueFields = new Set<string>();
      const audioFieldNames = new Set<string>();

      for (const col of selectedColumns) {
        const fieldName = col.endsWith("__AUDIO__")
          ? col.replace("__AUDIO__", "")
          : col;
        uniqueFields.add(fieldName);
        if (col.endsWith("__AUDIO__")) {
          audioFieldNames.add(fieldName);
        }
      }

      samplesExecutor.execute({
        fields: Array.from(uniqueFields),
        audio_fields: Array.from(audioFieldNames),
        skip,
        limit: rowsPerPage,
      });
    }
  }, [selectedColumns, page, rowsPerPage, view, filters, extendedSelection]);

  // Update samples when executor returns
  useEffect(() => {
    if (samplesExecutor.result) {
      const result = samplesExecutor.result as SamplesResult & {
        audio_urls?: Record<string, Record<string, string>>;
      };
      setSamples(result.samples || []);
      setAudioUrls(result.audio_urls || {});
      setTotal(result.total || 0);
    }
  }, [samplesExecutor.result]);

  // Check if a field can have audio player (audio or video media type)
  const canHaveAudioPlayer = (fieldName: string) => {
    return (
      (mediaType === "audio" || mediaType === "video") &&
      (fieldName === "filepath" || fieldName.endsWith("path"))
    );
  };

  const handleFieldsChange = (event: SelectChangeEvent<string[]>) => {
    const value = event.target.value;
    const newColumns = typeof value === "string" ? value.split(",") : value;
    setSelectedColumns(newColumns);
    setPage(0);
  };

  const handleSaveAsDefault = () => {
    if (dataset) {
      // Save column IDs with widths
      const columnsToSave = selectedColumns.map((columnId) => {
        const width = columnWidths[columnId];
        return width ? `${columnId}::${width}` : columnId;
      });
      setDefaultsExecutor.execute({ columns: columnsToSave });
    }
  };

  // Update savedColumns when set operation completes
  useEffect(() => {
    if (setDefaultsExecutor.result?.success) {
      setSavedColumns(setDefaultsExecutor.result.columns);
    }
  }, [setDefaultsExecutor.result]);

  const handleResetToSmart = () => {
    const defaultFields = getSmartDefaultFields(fields);
    setSelectedFields(defaultFields);
    setPage(0);
    // Clear saved defaults
    if (dataset) {
      setDefaultsExecutor.execute({ columns: [] });
    }
  };

  const handleChangePage = (_event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handlePageJump = () => {
    const sampleNumber = parseInt(pageJumpInput, 10);

    if (!isNaN(sampleNumber) && sampleNumber >= 1 && sampleNumber <= total) {
      // Convert sample number to page (0-indexed)
      // Sample 1 = page 0, sample 26 = page 1 (if 25 per page), etc.
      const targetPage = Math.floor((sampleNumber - 1) / rowsPerPage);
      setPage(targetPage);
      setPageJumpInput("");
    }
  };

  const handlePageJumpKeyDown = (
    event: React.KeyboardEvent<HTMLInputElement>
  ) => {
    if (event.key === "Enter") {
      handlePageJump();
    }
  };

  const handleRowClick = async (sampleId: string) => {
    // Initialize modal state without navigation (no next/previous)
    await setModalState();
    // Open the sample modal
    await setExpandedSample({ id: sampleId });
  };

  // Selection handlers
  const handleSelectSample = (sampleId: string, isChecked: boolean) => {
    setSelectedSamples((prev) => {
      const newSet = new Set(prev);
      if (isChecked) {
        newSet.add(sampleId);
      } else {
        newSet.delete(sampleId);
      }
      return newSet;
    });
  };

  const handleSelectAll = (isChecked: boolean) => {
    if (isChecked) {
      const allIds = new Set(samples.map((s) => s.id));
      setSelectedSamples(allIds);
    } else {
      setSelectedSamples(new Set());
    }
  };

  const isAllSelected =
    samples.length > 0 && samples.every((s) => selectedSamples.has(s.id));
  const isSomeSelected =
    samples.some((s) => selectedSamples.has(s.id)) && !isAllSelected;

  // Drag and drop handlers for column reordering
  const handleDragStart = (columnId: string) => {
    setDraggedColumn(columnId);
  };

  const handleDragOver = (e: React.DragEvent, columnId: string) => {
    e.preventDefault();
    if (draggedColumn && draggedColumn !== columnId) {
      setDragOverColumn(columnId);
    }
  };

  const handleDragLeave = () => {
    setDragOverColumn(null);
  };

  const handleDrop = (e: React.DragEvent, targetColumnId: string) => {
    e.preventDefault();
    if (!draggedColumn || draggedColumn === targetColumnId) {
      setDraggedColumn(null);
      setDragOverColumn(null);
      return;
    }

    const newColumns = [...selectedColumns];
    const draggedIndex = newColumns.indexOf(draggedColumn);
    const targetIndex = newColumns.indexOf(targetColumnId);

    // Remove from old position
    newColumns.splice(draggedIndex, 1);
    // Insert at new position
    newColumns.splice(targetIndex, 0, draggedColumn);

    setSelectedColumns(newColumns);
    setDraggedColumn(null);
    setDragOverColumn(null);
  };

  const handleDragEnd = () => {
    setDraggedColumn(null);
    setDragOverColumn(null);
  };

  // Column resizing handlers
  const handleResizeStart = (fieldName: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setResizingColumn(fieldName);
  };

  const handleResizeMove = (e: MouseEvent) => {
    if (!resizingColumn) return;

    const header = document.querySelector(
      `[data-column="${resizingColumn}"]`
    ) as HTMLElement;
    if (!header) return;

    const rect = header.getBoundingClientRect();
    const newWidth = Math.max(80, e.clientX - rect.left);

    setColumnWidths((prev) => ({
      ...prev,
      [resizingColumn]: newWidth,
    }));
  };

  const handleResizeEnd = () => {
    setResizingColumn(null);
  };

  // Add/remove resize event listeners
  React.useEffect(() => {
    if (resizingColumn) {
      document.addEventListener("mousemove", handleResizeMove);
      document.addEventListener("mouseup", handleResizeEnd);
      return () => {
        document.removeEventListener("mousemove", handleResizeMove);
        document.removeEventListener("mouseup", handleResizeEnd);
      };
    }
  }, [resizingColumn]);

  const loading =
    schemaExecutor.isExecuting ||
    samplesExecutor.isExecuting ||
    setDefaultsExecutor.isExecuting;
  const error =
    schemaExecutor.error || samplesExecutor.error || setDefaultsExecutor.error;

  const hasCustomDefaults = savedColumns !== null && savedColumns.length > 0;

  if (!dataset) {
    return (
      <Container>
        <Box p={2}>
          <Alert severity="info">No dataset loaded</Alert>
        </Box>
      </Container>
    );
  }

  if (error) {
    return (
      <Container>
        <Box p={2}>
          <Alert severity="error">Error: {String(error)}</Alert>
        </Box>
      </Container>
    );
  }

  return (
    <Container>
      <Header>
        <TableActions />
        <FormControl
          size="small"
          sx={{
            minWidth: 200,
            "& .MuiOutlinedInput-root": {
              fontSize: "13px",
              backgroundColor:
                "var(--fo-palette-background-field, rgba(255, 255, 255, 0.05))",
              "& fieldset": {
                borderColor:
                  "var(--fo-palette-divider, rgba(255, 255, 255, 0.12))",
              },
              "&:hover fieldset": {
                borderColor: "var(--fo-palette-primary-main, #ffb682)",
              },
              "&.Mui-focused fieldset": {
                borderColor: "var(--fo-palette-primary-main, #ffb682)",
              },
            },
            "& .MuiInputLabel-root": {
              fontSize: "13px",
              color:
                "var(--fo-palette-text-secondary, rgba(255, 255, 255, 0.6))",
            },
            "& .MuiSelect-select": {
              color:
                "var(--fo-palette-text-primary, rgba(255, 255, 255, 0.9))",
            },
          }}
        >
          <Select
            multiple
            value={selectedColumns}
            onChange={handleFieldsChange}
            displayEmpty
            renderValue={(selected) => {
              if (selected.length === 0) return "Select fields...";
              return `${selected.length} column${selected.length > 1 ? "s" : ""}`;
            }}
            MenuProps={{
              PaperProps: {
                sx: {
                  backgroundColor:
                    "var(--fo-palette-background-paper, #202020)",
                  border:
                    "1px solid var(--fo-palette-divider, rgba(255, 255, 255, 0.12))",
                  maxHeight: 400,
                },
              },
            }}
          >
            {fields.flatMap((field) => {
              const items = [
                <MenuItem
                  key={field.name}
                  value={field.name}
                  sx={{
                    fontSize: "13px",
                    color:
                      "var(--fo-palette-text-primary, rgba(255, 255, 255, 0.9))",
                    "&:hover": {
                      backgroundColor:
                        "var(--fo-palette-action-hover, rgba(255, 255, 255, 0.08))",
                    },
                    "&.Mui-selected": {
                      backgroundColor:
                        "var(--fo-palette-action-selected, rgba(255, 182, 130, 0.16))",
                      "&:hover": {
                        backgroundColor:
                          "var(--fo-palette-action-selected, rgba(255, 182, 130, 0.24))",
                      },
                    },
                  }}
                >
                  {field.name}
                  <Box
                    component="span"
                    sx={{
                      ml: 1,
                      fontSize: "11px",
                      color:
                        "var(--fo-palette-text-tertiary, rgba(255, 255, 255, 0.4))",
                    }}
                  >
                    {field.type}
                  </Box>
                </MenuItem>
              ];

              // Add audio player option for audio/video fields
              if (canHaveAudioPlayer(field.name)) {
                items.push(
                  <MenuItem
                    key={`${field.name}__AUDIO__`}
                    value={`${field.name}__AUDIO__`}
                    sx={{
                      fontSize: "13px",
                      color:
                        "var(--fo-palette-text-primary, rgba(255, 255, 255, 0.9))",
                      "&:hover": {
                        backgroundColor:
                          "var(--fo-palette-action-hover, rgba(255, 255, 255, 0.08))",
                      },
                      "&.Mui-selected": {
                        backgroundColor:
                          "var(--fo-palette-action-selected, rgba(255, 182, 130, 0.16))",
                        "&:hover": {
                          backgroundColor:
                            "var(--fo-palette-action-selected, rgba(255, 182, 130, 0.24))",
                        },
                      },
                    }}
                  >
                    {field.name} (audio player)
                    <Box
                      component="span"
                      sx={{
                        ml: 1,
                        fontSize: "11px",
                        color:
                          "var(--fo-palette-text-tertiary, rgba(255, 255, 255, 0.4))",
                      }}
                    >
                      {field.type}
                    </Box>
                  </MenuItem>
                );
              }

              return items;
            })}
          </Select>
        </FormControl>

        <Tooltip title="Save current columns as default for this dataset">
          <Button
            onClick={handleSaveAsDefault}
            style={{
              fontSize: "12px",
              padding: "4px 12px",
              backgroundColor: hasCustomDefaults
                ? "var(--fo-palette-action-selected, rgba(255, 182, 130, 0.16))"
                : "transparent",
              border: "1px solid var(--fo-palette-divider, rgba(255, 255, 255, 0.12))",
            }}
          >
            {hasCustomDefaults ? "Update Default" : "Set as Default"}
          </Button>
        </Tooltip>

        {hasCustomDefaults && (
          <Tooltip title="Reset to smart defaults">
            <Button
              onClick={handleResetToSmart}
              style={{
                fontSize: "12px",
                padding: "4px 12px",
                backgroundColor: "transparent",
                border:
                  "1px solid var(--fo-palette-divider, rgba(255, 255, 255, 0.12))",
              }}
            >
              Reset
            </Button>
          </Tooltip>
        )}

        {loading && (
          <CircularProgress
            size={16}
            sx={{ color: "var(--fo-palette-primary-main, #ffb682)" }}
          />
        )}
        <Box
          sx={{
            ml: "auto",
            fontSize: "13px",
            color:
              "var(--fo-palette-text-secondary, rgba(255, 255, 255, 0.6))",
          }}
        >
          {total.toLocaleString()} sample{total !== 1 ? "s" : ""}
        </Box>
      </Header>

      <TableWrapper>
        <TableContainer
          sx={{
            maxHeight: "100%",
            overflow: "auto",
          }}
        >
          <Table
            size="small"
            stickyHeader
            sx={{
              minWidth: "100%",
              tableLayout: "auto",
              "& .MuiTableCell-root": {
                borderBottom:
                  "1px solid var(--fo-palette-divider, rgba(255, 255, 255, 0.12))",
                padding: "8px 12px",
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              },
            }}
          >
            <TableHead>
              <TableRow>
                <TableCell
                  padding="checkbox"
                  sx={{
                    backgroundColor:
                      "var(--fo-palette-background-body, #161616)",
                    position: "sticky",
                    top: 0,
                    zIndex: 2,
                    width: "48px",
                  }}
                >
                  <Checkbox
                    checked={isAllSelected}
                    indeterminate={isSomeSelected}
                    onChange={(e) => handleSelectAll(e.target.checked)}
                    sx={{
                      color:
                        "var(--fo-palette-text-secondary, rgba(255, 255, 255, 0.6))",
                      "&.Mui-checked": {
                        color: "var(--fo-palette-primary-main, #ffb682)",
                      },
                      "&.MuiCheckbox-indeterminate": {
                        color: "var(--fo-palette-primary-main, #ffb682)",
                      },
                    }}
                  />
                </TableCell>
                {selectedColumns.map((columnId) => {
                  const isAudioColumn = columnId.endsWith("__AUDIO__");
                  const fieldName = isAudioColumn
                    ? columnId.replace("__AUDIO__", "")
                    : columnId;

                  return (
                    <TableCell
                      key={columnId}
                      data-column={columnId}
                      draggable
                      onDragStart={() => handleDragStart(columnId)}
                      onDragOver={(e) => handleDragOver(e, columnId)}
                      onDragLeave={handleDragLeave}
                      onDrop={(e) => handleDrop(e, columnId)}
                      onDragEnd={handleDragEnd}
                      sx={{
                        fontSize: "12px",
                        fontWeight: 600,
                        color:
                          "var(--fo-palette-text-secondary, rgba(255, 255, 255, 0.6))",
                        backgroundColor:
                          dragOverColumn === columnId
                            ? "var(--fo-palette-action-hover, rgba(255, 255, 255, 0.08))"
                            : "var(--fo-palette-background-body, #161616)",
                        textTransform: "none",
                        letterSpacing: "0.01em",
                        position: "sticky",
                        top: 0,
                        zIndex: 2,
                        minWidth: "120px",
                        width: columnWidths[columnId] || "auto",
                        maxWidth: columnWidths[columnId] || "none",
                        userSelect: "none",
                        padding: 0,
                        opacity: draggedColumn === columnId ? 0.5 : 1,
                        cursor: "move",
                      }}
                    >
                      <Box
                        sx={{
                          position: "relative",
                          padding: "8px 12px",
                          height: "100%",
                          display: "flex",
                          alignItems: "center",
                          gap: "6px",
                        }}
                      >
                        {fieldName}
                        {isAudioColumn && (
                          <GraphicEqIcon
                            sx={{
                              fontSize: "14px",
                              color:
                                "var(--fo-palette-text-tertiary, rgba(255, 255, 255, 0.4))",
                            }}
                          />
                        )}
                        <Box
                          onMouseDown={(e) => handleResizeStart(columnId, e)}
                          sx={{
                            position: "absolute",
                            right: 0,
                            top: 0,
                            bottom: 0,
                            width: "8px",
                            cursor: "col-resize",
                            borderRight:
                              resizingColumn === columnId
                                ? "2px solid var(--fo-palette-primary-main, #ffb682)"
                                : "1px solid var(--fo-palette-divider, rgba(255, 255, 255, 0.12))",
                            "&:hover": {
                              borderRight:
                                "2px solid var(--fo-palette-primary-main, #ffb682)",
                            },
                          }}
                        />
                      </Box>
                    </TableCell>
                  );
                })}
              </TableRow>
            </TableHead>
            <TableBody>
              {samples.map((sample) => (
                <TableRow
                  key={sample.id}
                  hover
                  onClick={() => handleRowClick(sample.id)}
                  selected={selectedSamples.has(sample.id)}
                  sx={{
                    cursor: "pointer",
                    "&:hover": {
                      backgroundColor:
                        "var(--fo-palette-action-hover, rgba(255, 255, 255, 0.08))",
                    },
                    "&.Mui-selected": {
                      backgroundColor:
                        "var(--fo-palette-action-selected, rgba(255, 182, 130, 0.08))",
                      "&:hover": {
                        backgroundColor:
                          "var(--fo-palette-action-selected, rgba(255, 182, 130, 0.12))",
                      },
                    },
                  }}
                >
                  <TableCell
                    padding="checkbox"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <Checkbox
                      checked={selectedSamples.has(sample.id)}
                      onChange={(e) =>
                        handleSelectSample(sample.id, e.target.checked)
                      }
                      sx={{
                        color:
                          "var(--fo-palette-text-secondary, rgba(255, 255, 255, 0.6))",
                        "&.Mui-checked": {
                          color: "var(--fo-palette-primary-main, #ffb682)",
                        },
                      }}
                    />
                  </TableCell>
                  {selectedColumns.map((columnId) => {
                    const isAudioColumn = columnId.endsWith("__AUDIO__");
                    const fieldName = isAudioColumn
                      ? columnId.replace("__AUDIO__", "")
                      : columnId;
                    const audioUrl = isAudioColumn
                      ? audioUrls[sample.id]?.[fieldName]
                      : null;

                    return (
                      <TableCell
                        key={`${sample.id}-${columnId}`}
                        title={
                          !isAudioColumn &&
                          sample[fieldName] !== null &&
                          sample[fieldName] !== undefined
                            ? String(sample[fieldName])
                            : ""
                        }
                        sx={{
                          fontSize: "13px",
                          color:
                            "var(--fo-palette-text-primary, rgba(255, 255, 255, 0.9))",
                          fontFamily: "monospace",
                          minWidth: "120px",
                          width: columnWidths[columnId] || "auto",
                          maxWidth: columnWidths[columnId] || "none",
                        }}
                        onClick={(e) => {
                          // Prevent row click when clicking on audio player
                          if (isAudioColumn) {
                            e.stopPropagation();
                          }
                        }}
                      >
                        {isAudioColumn && audioUrl ? (
                          <audio
                            controls
                            src={audioUrl}
                            style={{
                              width: "100%",
                              maxWidth: "300px",
                              height: "32px",
                              colorScheme: theme,
                            }}
                          >
                            Your browser does not support the audio element.
                          </audio>
                        ) : sample[fieldName] !== null &&
                          sample[fieldName] !== undefined ? (
                          String(sample[fieldName])
                        ) : (
                          "-"
                        )}
                      </TableCell>
                    );
                  })}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </TableWrapper>

      <PaginationWrapper>
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 2,
            pr: 2,
          }}
        >
          <TablePagination
            rowsPerPageOptions={[10, 25, 50, 100]}
            component="div"
            count={total}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
            sx={{
              fontSize: "13px",
              color:
                "var(--fo-palette-text-secondary, rgba(255, 255, 255, 0.6))",
              flex: 1,
              "& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows":
                {
                  fontSize: "13px",
                  color:
                    "var(--fo-palette-text-secondary, rgba(255, 255, 255, 0.6))",
                },
              "& .MuiTablePagination-select": {
                fontSize: "13px",
                color:
                  "var(--fo-palette-text-primary, rgba(255, 255, 255, 0.9))",
              },
              "& .MuiIconButton-root": {
                color:
                  "var(--fo-palette-text-secondary, rgba(255, 255, 255, 0.6))",
                "&:hover": {
                  backgroundColor:
                    "var(--fo-palette-action-hover, rgba(255, 255, 255, 0.08))",
                },
                "&.Mui-disabled": {
                  color:
                    "var(--fo-palette-text-disabled, rgba(255, 255, 255, 0.3))",
                },
              },
            }}
          />
          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            <Box
              sx={{
                fontSize: "13px",
                color:
                  "var(--fo-palette-text-secondary, rgba(255, 255, 255, 0.6))",
                whiteSpace: "nowrap",
              }}
            >
              Go to sample:
            </Box>
            <TextField
              size="small"
              value={pageJumpInput}
              onChange={(e) => setPageJumpInput(e.target.value)}
              onKeyDown={handlePageJumpKeyDown}
              placeholder={(page * rowsPerPage + 1).toString()}
              type="number"
              inputProps={{
                min: 1,
                max: total,
                style: { textAlign: "center" },
              }}
              sx={{
                width: "100px",
                "& .MuiOutlinedInput-root": {
                  fontSize: "13px",
                  backgroundColor:
                    "var(--fo-palette-background-field, rgba(255, 255, 255, 0.05))",
                  "& fieldset": {
                    borderColor:
                      "var(--fo-palette-divider, rgba(255, 255, 255, 0.12))",
                  },
                  "&:hover fieldset": {
                    borderColor: "var(--fo-palette-primary-main, #ffb682)",
                  },
                  "&.Mui-focused fieldset": {
                    borderColor: "var(--fo-palette-primary-main, #ffb682)",
                  },
                  "& input": {
                    color:
                      "var(--fo-palette-text-primary, rgba(255, 255, 255, 0.9))",
                    padding: "6px 8px",
                  },
                },
              }}
            />
            <Button
              onClick={handlePageJump}
              disabled={
                !pageJumpInput ||
                isNaN(parseInt(pageJumpInput, 10)) ||
                parseInt(pageJumpInput, 10) < 1 ||
                parseInt(pageJumpInput, 10) > total
              }
              style={{
                fontSize: "12px",
                padding: "6px 12px",
                backgroundColor: "transparent",
                border:
                  "1px solid var(--fo-palette-divider, rgba(255, 255, 255, 0.12))",
                minWidth: "50px",
              }}
            >
              Go
            </Button>
          </Box>
        </Box>
      </PaginationWrapper>
    </Container>
  );
}
