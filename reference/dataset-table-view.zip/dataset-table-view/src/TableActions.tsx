import { useOperatorExecutor } from "@fiftyone/operators";
import { Box, IconButton, Tooltip } from "@mui/material";
import LocalOfferIcon from "@mui/icons-material/LocalOffer";
import TravelExploreIcon from "@mui/icons-material/TravelExplore";
import React from "react";

export default function TableActions() {
  // Note: Table-specific operators will only work after FiftyOne restart
  // Comment out these hooks until operators are loaded to avoid errors
  // const tagOperator = useOperatorExecutor(
  //   "@voxel51/dataset-table-view/tag_samples_in_table"
  // );
  // const similarityOperator = useOperatorExecutor(
  //   "@voxel51/dataset-table-view/similarity_search_in_table"
  // );

  return (
    <Box sx={{ display: "flex", alignItems: "center", gap: 1, flex: 1 }}>
      {/* Table-specific action buttons - commented out until FiftyOne reloads operators
      <Tooltip title="Tag selected samples">
        <IconButton
          onClick={() => tagOperator.execute({})}
          size="small"
          sx={{
            color: "var(--fo-palette-text-secondary, rgba(255, 255, 255, 0.6))",
            "&:hover": {
              color: "var(--fo-palette-primary-main, #ffb682)",
              backgroundColor:
                "var(--fo-palette-action-hover, rgba(255, 255, 255, 0.08))",
            },
          }}
        >
          <LocalOfferIcon fontSize="small" />
        </IconButton>
      </Tooltip>

      <Tooltip title="Find similar samples">
        <IconButton
          onClick={() => similarityOperator.execute({})}
          size="small"
          sx={{
            color: "var(--fo-palette-text-secondary, rgba(255, 255, 255, 0.6))",
            "&:hover": {
              color: "var(--fo-palette-primary-main, #ffb682)",
              backgroundColor:
                "var(--fo-palette-action-hover, rgba(255, 255, 255, 0.08))",
            },
          }}
        >
          <TravelExploreIcon fontSize="small" />
        </IconButton>
      </Tooltip>
      */}
    </Box>
  );
}
