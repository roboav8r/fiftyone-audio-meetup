import { PluginComponentType, registerComponent } from "@fiftyone/plugins";
import TableChartIcon from "@mui/icons-material/TableChart";
import { DatasetTableView } from "./DatasetTableView";

registerComponent({
  name: "DatasetTableView",
  label: "Table",
  component: DatasetTableView,
  type: PluginComponentType.Panel,
  activator: myActivator,
  Icon: TableChartIcon,
  panelOptions: {
    surfaces: "grid",
  },
});

function myActivator({ dataset }) {
  // Example of activating the plugin in a particular context
  // return dataset.name === 'quickstart'

  return true;
}
